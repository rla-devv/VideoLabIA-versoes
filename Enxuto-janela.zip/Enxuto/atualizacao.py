# Atualização do Enxuto em janela — mesmo modelo do DegravaIA.
#
# verificar()  consulta atualizacao.json no repositório PÚBLICO de versões.
# instalar()   baixa a página nova, confere e troca o index.html.
# restaurar()  volta para a versão anterior (guardada em versoes-anteriores/).
#
# Só a página do app (index.html) é trocada. Nunca são tocados: .venv/, ffmpeg/, logs/,
# dados-janela/ (preferências da janela) e versoes-anteriores/.
import hashlib
import json
import os
import re
import shutil
import ssl
import time
import urllib.request
from pathlib import Path

APP = Path(__file__).resolve().parent
REPO_VERSOES = os.environ.get('ENXUTO_REPO_VERSOES', 'https://raw.githubusercontent.com/rla-devv/enxuto-versoes/main/')
PAGINA = APP / 'index.html'
ANTERIORES = APP / 'versoes-anteriores'
VER_RE = re.compile(r'^\d+(\.\d+){1,3}$')
_cache = {'quando': 0.0, 'manifesto': None}


def _ver(v):
    return tuple(int(x) for x in v.split('.'))


def versao_de(texto):
    m = re.search(r'<span id="app-version">([^<]+)</span>', texto)
    return m.group(1) if m else '0.0.0'


def versao_instalada():
    try:
        return versao_de(PAGINA.read_text(encoding='utf-8'))
    except OSError:
        return '0.0.0'


def _baixar(url, limite):
    req = urllib.request.Request(url, headers={'User-Agent': 'Enxuto', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=30, context=ssl.create_default_context()) as r:
        dados = r.read(limite + 1)
    if len(dados) > limite:
        raise ValueError('arquivo maior que o esperado')
    return dados


def _manifesto(forcar=False):
    # Guarda a resposta por 5 min (o GitHub também guarda cópia por uns 5 min); "Buscar atualização" força.
    if not forcar and _cache['manifesto'] and time.time() - _cache['quando'] < 300:
        return _cache['manifesto']
    m = json.loads(_baixar(REPO_VERSOES + f'atualizacao.json?t={int(time.time() // 60)}', 64_000))
    ok = (isinstance(m, dict) and VER_RE.match(str(m.get('versao', '')))
          and re.fullmatch(r'Enxuto-\d+(\.\d+){1,3}\.html', str(m.get('arquivo', '')))
          and re.fullmatch(r'[0-9a-f]{64}', str(m.get('sha256', '')))
          and isinstance(m.get('tamanho'), int) and 100_000 < m['tamanho'] < 64_000_000)
    if not ok:
        raise ValueError('atualizacao.json inválido')
    nov = m.get('novidades') or []
    m['novidades'] = [n for n in (nov if isinstance(nov, list) else [nov]) if isinstance(n, str) and n.strip()][:8]
    _cache.update(quando=time.time(), manifesto=m)
    return m


def verificar(forcar=False):
    atual = versao_instalada()
    m = _manifesto(forcar)
    nova = {'versao': m['versao'], 'novidades': m['novidades']} if _ver(m['versao']) > _ver(atual) else None
    return {'atual': atual, 'nova': nova}


def instalar():
    """Baixa, confere tudo e só então troca o index.html. Se algo falhar, nada muda."""
    atual = versao_instalada()
    m = _manifesto(forcar=True)
    if _ver(m['versao']) <= _ver(atual):
        raise ValueError(f'a versão publicada ({m["versao"]}) não é mais nova que a instalada ({atual})')
    dados = _baixar(REPO_VERSOES + 'versoes/' + m['arquivo'], m['tamanho'])
    # Regras de segurança, todas antes de trocar qualquer arquivo:
    if len(dados) != m['tamanho']:
        raise ValueError('o tamanho baixado não é o anunciado')
    if hashlib.sha256(dados).hexdigest() != m['sha256']:
        raise ValueError('o conteúdo baixado não confere com o anunciado (SHA-256)')
    texto = dados.decode('utf-8')
    if not texto.lower().startswith('<!doctype html>') or versao_de(texto) != m['versao'] \
            or f"const APP_VERSION = '{m['versao']}'" not in texto:
        raise ValueError('a versão escrita dentro do pacote não é a anunciada')
    # Guarda a versão atual para poder voltar.
    ANTERIORES.mkdir(exist_ok=True)
    shutil.copy2(PAGINA, ANTERIORES / f'Enxuto-{atual}.html')
    # Escreve ao lado e renomeia: o index.html nunca fica pela metade.
    novo = PAGINA.with_name('index.html.novo')
    novo.write_bytes(dados)
    os.replace(novo, PAGINA)
    _cache.update(quando=0.0, manifesto=None)
    return m['versao']


def restaurar():
    """Volta para a versão anterior mais recente guardada em versoes-anteriores/."""
    guardadas = sorted(ANTERIORES.glob('Enxuto-*.html'), key=lambda p: _ver(p.stem.split('-', 1)[1]))
    if not guardadas:
        raise ValueError('não há versão anterior guardada')
    volta = guardadas[-1]
    atual = versao_instalada()
    shutil.copy2(PAGINA, ANTERIORES / f'Enxuto-{atual}.html.desfeita')
    novo = PAGINA.with_name('index.html.novo')
    shutil.copy2(volta, novo)
    os.replace(novo, PAGINA)
    volta.unlink()
    return versao_instalada()
