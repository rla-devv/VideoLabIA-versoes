# Cria o atalho do Enxuto na Area de Trabalho e no Menu Iniciar.
$ErrorActionPreference = 'Stop'
$app = Split-Path -Parent $MyInvocation.MyCommand.Path
$shell = New-Object -ComObject WScript.Shell
foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $atalho = $shell.CreateShortcut((Join-Path $pasta 'Enxuto.lnk'))
  $atalho.TargetPath = Join-Path $app '.venv\Scripts\pythonw.exe'
  $atalho.Arguments = '"' + (Join-Path $app 'enxuto.pyw') + '"'
  $atalho.WorkingDirectory = $app
  $atalho.IconLocation = Join-Path $app 'assets\enxuto.ico'
  $atalho.Description = 'Enxuto - conversao, compressao e otimizacao de videos'
  $atalho.Save()
}
Write-Host ' Atalhos criados.'
