@echo off
chcp 65001 >nul
rem Este arquivo e UTF-8 sem BOM: depois do chcp 65001 o cmd le os acentos das mensagens corretamente.
setlocal
cd /d "%~dp0"
title Enxuto IA - Instalação
echo.
echo  Enxuto IA - Conversão, compressão e otimização de vídeos diretamente no seu computador
echo.
echo  A internet é usada só durante a instalação, para baixar os componentes do programa.
echo  Depois de instalado, o Enxuto IA funciona sem internet.
echo.
set "REPO=https://raw.githubusercontent.com/rla-devv/enxuto-versoes/main/"
if defined ENXUTO_REPO_VERSOES set "REPO=%ENXUTO_REPO_VERSOES%"
rem Confere a internet antes de baixar qualquer coisa: sem ela, avisa na hora em vez de parar no meio.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing -Method Head -TimeoutSec 20 -Uri ($env:REPO + 'atualizacao.json') | Out-Null } catch { exit 1 }" || goto sem_internet
echo  Instalando o Enxuto IA...
echo.
rem Python so do Enxuto IA: o portatil oficial do python.org, em python\ (nao mexe no resto do computador).
rem Instalacoes de antes da 1.10.2 continuam com o .venv.
set "PY_URL=https://www.python.org/ftp/python/3.14.8/python-3.14.8-embed-amd64.zip"
set "PY_SHA=a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310"
set "PYEXE=python\python.exe"
set "PYW=python\pythonw.exe"
if exist ".venv\Scripts\python.exe" (
  set "PYEXE=.venv\Scripts\python.exe"
  set "PYW=.venv\Scripts\pythonw.exe"
)
if not exist "%PYEXE%" (
  echo  Baixando o Python do Enxuto IA ^(cerca de 13 MB, só na primeira vez^)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $z=Join-Path $env:TEMP 'enxuto-python.zip'; Invoke-WebRequest -UseBasicParsing -TimeoutSec 60 -Uri $env:PY_URL -OutFile $z; if ((Get-FileHash -Algorithm SHA256 $z).Hash -ne $env:PY_SHA) { Remove-Item $z; throw 'o arquivo baixado nao confere com o esperado (SHA-256)' }; Expand-Archive -Force $z 'python'; Remove-Item $z; $pth=(Get-ChildItem 'python\python*._pth')[0].FullName; (Get-Content $pth) -replace '^#\s*import site','import site' | Set-Content -Encoding ascii $pth" || goto erro
)
rem O pacote so traz este arquivo: o programa vem do repositorio de versoes, conferido (tamanho e SHA-256) pelo
rem atualizacao.json, como nas atualizacoes. Pasta com um enxuto.pyw antigo (sem o --instalar): troca por um novo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; if ((Test-Path 'enxuto.pyw') -and (Select-String -Quiet -SimpleMatch 'def instalar_programa' 'enxuto.pyw')) { exit 0 }; Write-Host ' Baixando o Enxuto IA...'; $m=(Invoke-WebRequest -UseBasicParsing -TimeoutSec 60 -Uri ($env:REPO + 'atualizacao.json?t=' + [DateTimeOffset]::Now.ToUnixTimeMilliseconds())).Content | ConvertFrom-Json; $it=@($m.janela.arquivos | Where-Object { $_.caminho -eq 'enxuto.pyw' })[0]; if (-not $it -or $it.origem -match '\.\.' -or $it.origem -match '^[/\\]') { throw 'o atualizacao.json nao traz o programa' }; $f='enxuto.pyw.novo'; Invoke-WebRequest -UseBasicParsing -TimeoutSec 60 -Uri ($env:REPO + $it.origem) -OutFile $f; if ((Get-Item $f).Length -ne $it.tamanho -or (Get-FileHash -Algorithm SHA256 $f).Hash -ne $it.sha256) { Remove-Item $f; throw 'o programa baixado nao confere com o esperado (SHA-256)' }; Move-Item -Force $f 'enxuto.pyw'" || goto erro
"%PYEXE%" enxuto.pyw --instalar || goto erro
echo.
echo  Pronto! O Enxuto IA está abrindo.
echo  Para abrir depois, use o atalho 'Abrir o Enxuto IA' nesta pasta ou o atalho 'Enxuto IA'
echo  na Área de Trabalho e no Menu Iniciar.
echo.
start "" "%~dp0%PYW%" "%~dp0enxuto.pyw"
timeout /t 6 >nul
exit /b 0
:sem_internet
echo  Sem conexão com a internet.
echo  A instalação precisa de internet para baixar os componentes do programa (só desta vez).
echo  Conecte o computador à internet e rode este arquivo de novo.
echo.
pause
exit /b 1
:erro
echo.
echo  A instalação não terminou. Veja a mensagem acima.
echo  Confira a internet (ela é usada só durante a instalação) e rode este arquivo de novo.
echo.
pause
exit /b 1
